#include <stdio.h>

void magic_square(int **, int);

int main()
{
    
}